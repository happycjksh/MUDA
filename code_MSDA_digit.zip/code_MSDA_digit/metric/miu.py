import torch
from torch import nn
import torch.nn.functional as F
import numpy as np



class Miu(nn.Module):


    def __init__(self):
        super(Miu, self).__init__()
        self.fc1 = nn.Linear(2,128)
        self.fc2 = nn.Linear(128,192)
        self.fc3 = nn.Linear(192,2)
        self.relu = nn.ReLU(inplace=True)
        self.sigmoid=nn.Sigmoid() 


    def forward(self, mmd, lmmd):
        mmd=mmd.reshape([1,1])
        lmmd=lmmd.reshape([1,1])
        input_lst=[mmd,lmmd]
        x1=torch.cat((mmd,lmmd),1)

        

        gap = self.fc1(x1)
        gap = self.relu(gap)
        gap = self.fc2(gap)
        gap = self.relu(gap)
        gap =self.fc3(gap)
        gap =self.sigmoid(gap)
        atten = F.softmax(gap, dim=1)
        atten_lst = torch.split(atten, 1, dim=1)


        # [input_nb, input_nc, input_h, input_w]
        out = sum([att * x for (att, x) in zip(atten_lst, input_lst)])

        return out
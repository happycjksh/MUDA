from __future__ import print_function
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import mmd
import msda
from torch.autograd import Variable
from model.build_gen import *
from datasets.dataset_read import dataset_read
import numpy as np
from matplotlib import pyplot as plt
import math
#from visdom import Visdom
import miu


# Training settings
class Solver(object):
    def __init__(self, args, batch_size=128,
                 target='mnist', learning_rate=0.0002, interval=100, optimizer='adam'
                 , checkpoint_dir=None, save_epoch=10):
        self.batch_size = batch_size
        self.target = target
        self.checkpoint_dir = checkpoint_dir
        self.save_epoch = save_epoch
        self.use_abs_diff = args.use_abs_diff
        
        '''self.vis = Visdom(env='JACFL')
        self.vis.line([0.], [0.], win='loss_msda1', opts=dict(title='loss_msda1'))
        self.vis.line([0.], [0.], win='loss_msda2', opts=dict(title='loss_msda2'))
        self.vis.line([0.], [0.], win='train_loss', opts=dict(title='train_loss'))
        self.vis.line([0.], [0.], win='test_loss', opts=dict(title='test_loss'))
        self.vis.line([0.], [0.], win='Accuracy', opts=dict(title='Accuracy'))'''
        self.global_step=0
        
        self.miu1=miu.Miu().cuda()
    
        print('dataset loading')
        self.datasets, self.dataset_test = dataset_read(target, self.batch_size)

    
        print('load finished!')
        self.G = Generator()
        self.C1 = Classifier()
        self.C2 = Classifier()
        self.C3 = Classifier()
        '''self.domain_C1 = Discriminator1()
        self.domain_C2 = Discriminator2()
        self.domain_C3 = Discriminator3()
        self.domain_C4 = Discriminator4()'''
        print('model_loaded')
        

        if args.eval_only:
            self.G.torch.load(
                '%s/%s_to_%s_model_epoch%s_G.pt' % (self.checkpoint_dir, self.source, self.target, args.resume_epoch))
            self.G.torch.load(
                '%s/%s_to_%s_model_epoch%s_G.pt' % (
                    self.checkpoint_dir, self.source, self.target, self.checkpoint_dir, args.resume_epoch))
            self.G.torch.load(
                '%s/%s_to_%s_model_epoch%s_G.pt' % (self.checkpoint_dir, self.source, self.target, args.resume_epoch))
        
        self.G.cuda()
        self.C1.cuda()
        self.C2.cuda()
        self.C3.cuda()
        '''self.domain_C1.cuda()
        self.domain_C2.cuda()
        self.domain_C3.cuda()
        self.domain_C4.cuda()'''
        self.interval = interval

        
        print('initialize complete')
        

    def set_optimizer(self, which_opt='momentum', lr=0.001, momentum=0.9):
        if which_opt == 'momentum':
            self.opt_g = optim.SGD(self.G.parameters(),
                                   lr=lr, weight_decay=0.0005,
                                   momentum=momentum)

            self.opt_c1 = optim.SGD(self.C1.parameters(),
                                    lr=lr, weight_decay=0.0005,
                                    momentum=momentum)
            self.opt_c2 = optim.SGD(self.C2.parameters(),
                                    lr=lr, weight_decay=0.0005,
                                    momentum=momentum)

        if which_opt == 'adam':
            self.opt_g = optim.Adam(self.G.parameters(),
                                    lr=lr, weight_decay=0.0005)

            self.opt_c1 = optim.Adam(self.C1.parameters(),
                                     lr=lr, weight_decay=0.0005)
            self.opt_c2 = optim.Adam(self.C2.parameters(),
                                     lr=lr, weight_decay=0.0005)
            self.opt_c3 = optim.Adam(self.C3.parameters(),lr=lr, weight_decay=0.0005)
            
            '''self.opt_dom1 = optim.Adam(self.domain_C1.parameters(),
                                     lr=lr, weight_decay=0.0005)
            self.opt_dom2 = optim.Adam(self.domain_C2.parameters(),
                                     lr=lr, weight_decay=0.0005)
            self.opt_dom3 = optim.Adam(self.domain_C3.parameters(),
                                       lr=lr, weight_decay=0.0005)
            self.opt_dom4 = optim.Adam(self.domain_C4.parameters(),
                                       lr=lr, weight_decay=0.0005)'''
            
            self.opt_miu1 = optim.Adam(self.miu1.parameters(),lr=lr, weight_decay=0.0005)



    def reset_grad(self):
        self.opt_g.zero_grad()
        self.opt_c1.zero_grad()
        self.opt_c2.zero_grad()
        self.opt_c3.zero_grad()
        '''self.opt_dom1.zero_grad()
        self.opt_dom2.zero_grad()
        self.opt_dom3.zero_grad()
        self.opt_dom4.zero_grad()'''
        self.opt_miu1.zero_grad()
        
 
    def ent(self, output):
        return - torch.mean(output * torch.log(output + 1e-6))

   
    def discrepancy(self, out1, out2):
        return torch.mean(torch.abs(F.softmax(out1) - F.softmax(out2)))


    def test(self, epoch, record_file=None, save_model=False):
        self.G.eval()
        self.C1.eval()
        self.miu1.eval()

        test_loss = 0
        correct1 = 0
        size = 0
        feature_all = np.array([])
        label_all = []
        for batch_idx, data in enumerate(self.dataset_test):
            img = data['T']
            label = data['T_label']

            img, label = img.cuda(), label.long().cuda()
            img, label = Variable(img, volatile=True), Variable(label)
            feat = self.G(img)
            
            output1 = self.C1(feat)
            
            test_loss += F.nll_loss(output1, label).item()
            pred1 = output1.data.max(1)[1]
            k = label.data.size()[0]
            correct1 += pred1.eq(label.data).cpu().sum()
            size += k
        np.savez('result_plot_sv_t', feature_all, label_all )
        test_loss = test_loss / size
        
        '''self.vis.line([test_loss], [self.global_step], win='test_loss', update='append')
        self.vis.line([ 100. *correct1 / size], [self.global_step], win='Accuracy', update='append')'''
        
        print(
            '\nTest set: Average loss: {:.4f}, Accuracy C1: {}/{} ({:.2f}%)  \n'.format(
                test_loss, correct1, size,   100. * correct1 / size))
        
        if save_model and epoch % self.save_epoch == 0:
            torch.save(self.G,
                       '%s/%s_to_%s_model_epoch%s_G.pt' % (self.checkpoint_dir, self.source, self.target, epoch))
            torch.save(self.C1,
                       '%s/%s_to_%s_model_epoch%s_C1.pt' % (self.checkpoint_dir, self.source, self.target, epoch))
            torch.save(self.C2,
                       '%s/%s_to_%s_model_epoch%s_C2.pt' % (self.checkpoint_dir, self.source, self.target, epoch))
        if record_file:
            record = open(record_file, 'a')
            print('recording %s', record_file)
            record.write('%s\n' % (float(correct1) / size))
            record.close()
        accuracy1=100. * correct1 / size
        
        def load_data():
            source_test_loader = data_loader.load_testing(root_path, source_dir, 32, kwargs)
            target_test_loader = data_loader.load_testing(root_path, test_dir, 32, kwargs)
            return source_test_loader, target_test_loader
        
        def load_pretrain(model):
            premodel = torch.load("atow.pkl")
            pretrained_dict = premodel.state_dict()
            model_dict = model.state_dict()
            for k, v in model_dict.items():
                model_dict[k] = pretrained_dict[k]
                
            model.load_state_dict(model_dict)
            return model
        
        return accuracy1


    def feat_all_domain(self, img_s1, img_s2, img_s3, img_s4, img_t):
    	return self.G(img_s1), self.G(img_s2), self.G(img_s3), self.G(img_s4), self.G(img_t)

    def C1_all_domain(self, feat1, feat2,feat3,feat4, feat_t):
    	return self.C1(feat1), self.C1(feat2), self.C1(feat3), self.C1(feat4), self.C1(feat_t)
    
    def C2_all_domain(self, feat1, feat2,feat3,feat4, feat_t):
    	return self.C2(feat1), self.C2(feat2), self.C2(feat3), self.C2(feat4), self.C2(feat_t)
    
    def C3_all_domain(self, feat1, feat2,feat3,feat4, feat_t):
    	return self.C3(feat1), self.C3(feat2), self.C3(feat3), self.C3(feat4), self.C3(feat_t)
    
    '''def get_adversarial_result1(self, x, source=True, alpha=1):
        loss_fn = nn.BCELoss()
        if source:
            domain_label = torch.ones(len(x)).long().cuda()
        else:
            domain_label = torch.zeros(len(x)).long().cuda()
        domain_pred = self.domain_C1(x)
        loss_adv = loss_fn(domain_pred, domain_label.float())
        return loss_adv, domain_pred

    def get_adversarial_result2(self, x, source=True, alpha=1):
        loss_fn = nn.BCELoss()
        if source:
            domain_label = torch.ones(len(x)).long().cuda()
        else:
            domain_label = torch.zeros(len(x)).long().cuda()
        domain_pred = self.domain_C2(x)
        loss_adv = loss_fn(domain_pred, domain_label.float())
        return loss_adv, domain_pred

    def get_adversarial_result3(self, x, source=True, alpha=1):
        loss_fn = nn.BCELoss()
        if source:
            domain_label = torch.ones(len(x)).long().cuda()
        else:
            domain_label = torch.zeros(len(x)).long().cuda()
        domain_pred = self.domain_C3(x)
        loss_adv = loss_fn(domain_pred, domain_label.float())
        return loss_adv, domain_pred

    def get_adversarial_result4(self, x, source=True, alpha=1):
        loss_fn = nn.BCELoss()
        if source:
            domain_label = torch.ones(len(x)).long().cuda()
        else:
            domain_label = torch.zeros(len(x)).long().cuda()
        domain_pred = self.domain_C4(x)
        loss_adv = loss_fn(domain_pred, domain_label.float())
        return loss_adv, domain_pred'''

    def softmax_loss_all_domain(self, output1, output2, output3, output4, label_s1, label_s2, label_s3, label_s4):
    	criterion = nn.CrossEntropyLoss().cuda()
    	return criterion(output1, label_s1), criterion(output2, label_s2), criterion(output3, label_s3), criterion(output4,label_s4)

    def loss_all_domain(self, epoch, img_s1, img_s2, img_s3, img_s4, img_t, label_s1, label_s2, label_s3,label_s4):
        feat_s1, feat_s2, feat_s3, feat_s4, feat_t = self.feat_all_domain(img_s1, img_s2, img_s3, img_s4, img_t)
        output_s1_c1, output_s2_c1, output_s3_c1, output_s4_c1, output_t_c1 = self.C1_all_domain(feat_s1, feat_s2, feat_s3, feat_s4, feat_t)
        output_s1_c2, output_s2_c2, output_s3_c2, output_s4_c2, output_t_c2 = self.C2_all_domain(feat_s1, feat_s2, feat_s3, feat_s4, feat_t)
        output_s1_c3, output_s2_c3, output_s3_c3, output_s4_c3, output_t_c3 = self.C3_all_domain(feat_s1, feat_s2, feat_s3, feat_s4, feat_t)
        '''loss_domain_s1, domain_pred_s1 = self.get_adversarial_result1(feat_s1, True)
        loss_domain_s2, domain_pred_s2 = self.get_adversarial_result2(feat_s2, True)
        loss_domain_s3, domain_pred_s3 = self.get_adversarial_result3(feat_s3, True)
        loss_domain_s4, domain_pred_s4 = self.get_adversarial_result4(feat_s4, True)
        loss_domain_t1, domain_pred_t1 = self.get_adversarial_result1(feat_t, False)
        loss_domain_t2, domain_pred_t2 = self.get_adversarial_result2(feat_t, False)
        loss_domain_t3, domain_pred_t3 = self.get_adversarial_result3(feat_t, False)
        loss_domain_t4, domain_pred_t4 = self.get_adversarial_result4(feat_t, False)'''
        loss_msda1 = 0.0006 * self.miu1(*msda.msda_regulizer(feat_s1, feat_s2, feat_s3, feat_s4, feat_t, label_s1, label_s2, label_s3, label_s4))
        #loss_msda1 = 0.0006 * msda.msda_regulizer(feat_s1, feat_s2, feat_s3, feat_s4, feat_t, label_s1, label_s2, label_s3, label_s4)
        #loss_msda2 = 0.0006 * msda.msda_regulizer1(feat_s1, feat_s2, feat_s3, feat_s4, feat_t, label_s1, label_s2, label_s3, label_s4, F.softmax(output_t_c1, dim=1), domain_pred_s1, domain_pred_s2, domain_pred_s3, domain_pred_s4, domain_pred_t1, domain_pred_t2, domain_pred_t3, domain_pred_t4)
        loss_msda2 = 0.0006 * msda.msda_regulizer1(feat_s1, feat_s2, feat_s3, feat_s4, feat_t, label_s1, label_s2, label_s3, label_s4, F.softmax(output_t_c1, dim=1))
        loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1 = self.softmax_loss_all_domain(output_s1_c1, output_s2_c1, output_s3_c1,output_s4_c1, label_s1, label_s2, label_s3,label_s4)
        loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2 = self.softmax_loss_all_domain(output_s1_c2, output_s2_c2, output_s3_c2,output_s4_c2, label_s1, label_s2, label_s3,label_s4)
        loss_s1_c3, loss_s2_c3, loss_s3_c3, loss_s4_c3 = self.softmax_loss_all_domain(output_s1_c3, output_s2_c3, output_s3_c3,output_s4_c3, label_s1, label_s2, label_s3,label_s4)
        return  loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_s1_c3, loss_s2_c3, loss_s3_c3, loss_s4_c3, loss_msda1, loss_msda2
        #return  loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_domain_s1, loss_domain_s2, loss_domain_s3, loss_domain_s4, loss_domain_t1, loss_domain_t2, loss_domain_t3, loss_domain_t4, loss_msda1, loss_msda2
    
    def train_MSDA(self, epoch, record_file=None):
        self.lr = 0.0003 / math.pow((1 + 10 * epoch / 102), 0.75)
        self.set_optimizer(which_opt='adam', lr=self.lr)
        criterion = nn.CrossEntropyLoss().cuda()
        self.G.train()
        self.C1.train()
        self.C2.train()
        self.C3.train()
        '''self.domain_C1.train()
        self.domain_C2.train()
        self.domain_C3.train()
        self.domain_C4.train()'''
        self.miu1.train()
        torch.cuda.manual_seed(1)

        for batch_idx, data in enumerate(self.datasets):
            img_t = Variable(data['T'].cuda())
            img_s1 = Variable(data['S1'].cuda())
            img_s2 = Variable(data['S2'].cuda())
            img_s3 = Variable(data['S3'].cuda())
            img_s4 = Variable(data['S4'].cuda())
            label_s1 = Variable(data['S1_label'].long().cuda())
            label_s2 = Variable(data['S2_label'].long().cuda())
            label_s3 = Variable(data['S3_label'].long().cuda())
            label_s4 = Variable(data['S4_label'].long().cuda())


            if img_s1.size()[0] < self.batch_size or img_s2.size()[0] < self.batch_size  or img_s3.size()[0] < self.batch_size or img_s4.size()[0]<self.batch_size or img_t.size()[0] < self.batch_size:
                break            

            self.reset_grad()


            loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_s1_c3, loss_s2_c3, loss_s3_c3, loss_s4_c3, loss_msda1, loss_msda2 = self.loss_all_domain(epoch, img_s1, img_s2, img_s3, img_s4, img_t, label_s1, label_s2, label_s3, label_s4)
            #loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_domain_s1, loss_domain_s2, loss_domain_s3, loss_domain_s4, loss_domain_t1, loss_domain_t2, loss_domain_t3, loss_domain_t4, loss_msda1, loss_msda2 = self.loss_all_domain(epoch, img_s1, img_s2, img_s3, img_s4, img_t, label_s1, label_s2, label_s3, label_s4)

            loss_s_c1 = loss_s1_c1 + loss_s2_c1 + loss_s3_c1 + loss_s4_c1
            loss_s_c2 = loss_s1_c2 + loss_s2_c2 + loss_s3_c2 + loss_s4_c2
            loss_s_c3 = loss_s1_c3 + loss_s2_c3 + loss_s3_c3 + loss_s4_c3
            '''loss_domain_1 = loss_domain_s1 + loss_domain_t1
            loss_domain_2 = loss_domain_s2 + loss_domain_t2
            loss_domain_3 = loss_domain_s3 + loss_domain_t3
            loss_domain_4 = loss_domain_s4 + loss_domain_t4'''
            loss = loss_s_c1 + loss_s_c2 + loss_s_c3 + loss_msda1 + loss_msda2
            #loss = loss_s_c1 + loss_s_c2 + loss_domain_1 + loss_domain_2 + loss_domain_3 + loss_domain_4 + loss_msda1 + loss_msda2
            #self.vis.line([loss.item()], [self.global_step], win='train_loss', update='append')

            
            loss.backward()

            self.opt_g.step()
            self.opt_c1.step()
            self.opt_c2.step()
            self.opt_c3.step()
            '''self.opt_dom1.step()
            self.opt_dom2.step()
            self.opt_dom3.step()
            self.opt_dom4.step()'''
            self.opt_miu1.step()
            self.reset_grad()

            loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_s1_c3, loss_s2_c3, loss_s3_c3, loss_s4_c3, loss_msda1, loss_msda2 = self.loss_all_domain(epoch, img_s1, img_s2, img_s3, img_s4, img_t, label_s1, label_s2, label_s3, label_s4)    
            #loss_s1_c1, loss_s2_c1, loss_s3_c1, loss_s4_c1, loss_s1_c2, loss_s2_c2, loss_s3_c2, loss_s4_c2, loss_domain_s1, loss_domain_s2, loss_domain_s3, loss_domain_s4, loss_domain_t1, loss_domain_t2, loss_domain_t3, loss_domain_t4, loss_msda1, loss_msda2 = self.loss_all_domain(epoch, img_s1, img_s2, img_s3, img_s4, img_t, label_s1, label_s2, label_s3, label_s4)


            feat_t = self.G(img_t)
            output_t1 = self.C1(feat_t)
            output_t2 = self.C2(feat_t)
            output_t3 = self.C3(feat_t)
            loss_s_c1 = loss_s1_c1 + loss_s2_c1 + loss_s3_c1 + loss_s4_c1
            loss_s_c2 = loss_s1_c2 + loss_s2_c2 + loss_s3_c2 + loss_s4_c2
            loss_s_c3 = loss_s1_c3 + loss_s2_c3 + loss_s3_c3 + loss_s4_c3
            '''loss_domain_1 = loss_domain_s1 + loss_domain_t1
            loss_domain_2 = loss_domain_s2 + loss_domain_t2
            loss_domain_3 = loss_domain_s3 + loss_domain_t3
            loss_domain_4 = loss_domain_s4 + loss_domain_t4'''

            #loss_s = loss_s_c1 + loss_s_c2 + loss_domain_1 + loss_domain_2 + loss_domain_3 + loss_domain_4 + loss_msda1 + loss_msda2
            loss_s = loss_s_c1 + loss_s_c2 + loss_s_c3 + loss_msda1 + loss_msda2
            loss_dis1 = self.discrepancy(output_t1, output_t2)
            loss_dis2 = self.discrepancy(output_t1, output_t3)
            loss_dis3 = self.discrepancy(output_t2, output_t3)
            loss_dis = loss_dis1 + loss_dis2 + loss_dis3
            #loss_dis = loss_dis1
            loss = loss_s - loss_dis
            loss.backward()
            self.opt_c1.step()
            self.opt_c2.step()
            self.opt_c3.step()
            self.reset_grad()
            
            self.global_step += 1

            for i in range(4):
                feat_t = self.G(img_t)
                output_t1 = self.C1(feat_t)
                output_t2 = self.C2(feat_t)
                output_t3 = self.C3(feat_t)
                loss_dis1 = self.discrepancy(output_t1, output_t2)
                loss_dis2 = self.discrepancy(output_t1, output_t3)
                loss_dis3 = self.discrepancy(output_t2, output_t3)
                loss_dis = loss_dis1 + loss_dis2 + loss_dis3
                #loss_dis = loss_dis1
                loss_dis.backward()
                self.opt_g.step()
                self.reset_grad()

            if batch_idx % self.interval == 0:
                print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss1: {:.6f}\t Loss2: {:.6f}\t  Discrepancy: {:.6f}'.format(
                    epoch, batch_idx, 100,
                    100. * batch_idx / 70000, loss_s_c1.item(), loss_s_c2.item(), loss_dis.item()))
                if record_file:
                    record = open(record_file, 'a')
                    record.write('%s %s %s\n' % (loss_dis1.item(), loss_s_c1.item(), loss_s_c2.item()))
                    record.close()
                    
        self.global_step += 1
        return batch_idx

    
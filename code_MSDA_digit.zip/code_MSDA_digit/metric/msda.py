import torch
from lmmd import lmmd
from mmd import mix_rbf_mmd2
import numpy as np
import lmmdst


def euclidean(x1,x2):
	return ((x1-x2)**2).sum().sqrt()


def msda_regulizer(output_s1, output_s2, output_s3, output_s4, output_t, label_s1, label_s2, label_s3, label_s4):
	# print('s1:{}, s2:{}, s3:{}, s4:{}'.format(output_s1.shape, output_s2.shape, output_s3.shape, output_t.shape))
    s1_mean = output_s1.mean(0)
    s2_mean = output_s2.mean(0)
    s3_mean = output_s3.mean(0)
    s4_mean = output_s4.mean(0)
    output_s1 = output_s1 - s1_mean
    output_s2 = output_s2 - s2_mean
    output_s3 = output_s3 - s3_mean
    output_s4 = output_s4 - s4_mean
    sigma=[0.25, 0.5, 1, 2]
    loss1_2 = mix_rbf_mmd2(output_s1, output_s2, sigma)
    loss1_3 = mix_rbf_mmd2(output_s1, output_s3, sigma)
    loss1_4 = mix_rbf_mmd2(output_s1, output_s4, sigma)
    loss2_3 = mix_rbf_mmd2(output_s2, output_s3, sigma)
    loss2_4 = mix_rbf_mmd2(output_s2, output_s4, sigma)
    loss3_4 = mix_rbf_mmd2(output_s3, output_s4, sigma)
    
    global_mmd1 = loss1_2 + loss1_3 + loss1_4 + loss2_3 + loss2_4 + loss3_4
   
    lmmd_loss1=lmmd(output_s1, output_s2, label_s1, label_s2) + lmmd(output_s3, output_s1, label_s3, label_s1) + lmmd(output_s4, output_s1, label_s4, label_s1) + lmmd(output_s4, output_s3, label_s4, label_s3) + lmmd(output_s4, output_s2, label_s4, label_s2) + lmmd(output_s2, output_s3, label_s2, label_s3)
    
    #loss_sum = global_mmd1 + lmmd_loss1

    return global_mmd1, lmmd_loss1


'''def msda_regulizer1(output_s1, output_s2, output_s3, output_s4, output_t, label_s1, label_s2, label_s3, label_s4, label_t, domain_pred_s1, domain_pred_s2, domain_pred_s3, domain_pred_s4, domain_pred_t1, domain_pred_t2, domain_pred_t3, domain_pred_t4):
    s1_mean = output_s1.mean(0)
    s2_mean = output_s2.mean(0)
    s3_mean = output_s3.mean(0)
    s4_mean = output_s4.mean(0)
    t_mean = output_t.mean(0)
    output_s1 = output_s1 - s1_mean
    output_s2 = output_s2 - s2_mean
    output_s3 = output_s3 - s3_mean
    output_s4 = output_s4 - s4_mean
    output_t = output_t - t_mean

    
    lmmd_loss2 = lmmdst.lmmd(output_s1, output_t, label_s1, label_t, domain_pred_s1, domain_pred_t1) + lmmdst.lmmd(output_s2, output_t, label_s2, label_t, domain_pred_s2, domain_pred_t2) + lmmdst.lmmd(output_s3, output_t, label_s3, label_t, domain_pred_s3, domain_pred_t3) + lmmdst.lmmd(output_s4, output_t, label_s4, label_t, domain_pred_s4, domain_pred_t4)
    
    return lmmd_loss2
	#return euclidean(output_s1, output_t)'''

def msda_regulizer1(output_s1, output_s2, output_s3, output_s4, output_t, label_s1, label_s2, label_s3, label_s4, label_t):
    s1_mean = output_s1.mean(0)
    s2_mean = output_s2.mean(0)
    s3_mean = output_s3.mean(0)
    s4_mean = output_s4.mean(0)
    t_mean = output_t.mean(0)
    output_s1 = output_s1 - s1_mean
    output_s2 = output_s2 - s2_mean
    output_s3 = output_s3 - s3_mean
    output_s4 = output_s4 - s4_mean
    output_t = output_t - t_mean

    
    lmmd_loss2 = lmmdst.lmmd(output_s1, output_t, label_s1, label_t) + lmmdst.lmmd(output_s2, output_t, label_s2, label_t) + lmmdst.lmmd(output_s3, output_t, label_s3, label_t) + lmmdst.lmmd(output_s4, output_t, label_s4, label_t)
    
    return lmmd_loss2
	#return euclidean(output_s1, output_t)
# -*- coding: utf-8 -*-

import torch
from torch import nn
import torch.nn.functional as F


class SK_Conv(nn.Module):
    def __init__(self, num_inputs=3, input_nc=64, reduction=16):
        super(SK_Conv, self).__init__()
        self.fc1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc // reduction, 1),
            nn.BatchNorm2d(input_nc // reduction)
        )
        self.fc2 = nn.Conv2d(input_nc // reduction, input_nc * num_inputs, 1)
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, input_lst):
        num_inputs = len(input_lst)
        
        # [input_nb, input_nc, 1, 1]
        gap = F.adaptive_avg_pool2d(sum(input_lst), 1)
        input_nb, input_nc = gap.size()[:2]
        
        # [input_nb, input_nc // reduction, 1, 1]
        gap = self.fc1(gap)
        gap = self.relu(gap)
        
        # [input_nb, num_inputs, input_nc]
        atten = self.fc2(gap).view((input_nb, num_inputs, input_nc))
        # [input_nb, num_inputs * input_nc, 1, 1]
        atten = F.softmax(atten, dim=1).view(input_nb, -1, 1, 1)
        # num_inputs * [input_nb, input_nc, 1, 1]
        atten_lst = torch.split(atten, input_nc, dim=1)
        # [input_nb, input_nc, input_h, input_w]
        out = sum([att * x for (att, x) in zip(atten_lst, input_lst)])
        
        return out


class CM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128):
        super(CM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(x1)
        x2 = self.relu(x2)
        
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(x2)
        x3 = self.relu(x3)
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x3)
        out = self.relu(out)
        
        return out
    
    
class RM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128):
        super(RM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(x1)
        x2 = self.relu(x2)
        
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(x2)
        x3 = self.relu(x3)
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x + x3)
        out = self.relu(out)
        
        return out


class DM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128):
        super(DM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(2 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(3 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv = nn.Sequential(
            nn.Conv2d(4 * input_nc, input_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(input_nc),
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, 2 * input_nc, input_h, input_w]
        y1 = torch.cat((x, x1), 1)
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(y1)
        x2 = self.relu(x2)
        
        # [input_nb, 3 * input_nc, input_h, input_w]
        y2 = torch.cat((x, x1, x2), 1)
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(y2)
        x3 = self.relu(x3)
        
        # [input_nb, 4 * input_nc, input_h, input_w]
        y3 = torch.cat((x, x1, x2, x3), 1)
        # [input_nb, input_nc, input_h, input_w]
        x4 = self.conv(y3)
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x4)
        out = self.relu(out)
        
        return out


class RDM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128):
        super(RDM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(2 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(3 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv = nn.Sequential(
            nn.Conv2d(4 * input_nc, input_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(input_nc),
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, 2 * input_nc, input_h, input_w]
        y1 = torch.cat((x, x1), 1)
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(y1)
        x2 = self.relu(x2)
        
        # [input_nb, 3 * input_nc, input_h, input_w]
        y2 = torch.cat((x, x1, x2), 1)
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(y2)
        x3 = self.relu(x3)
        
        # [input_nb, 4 * input_nc, input_h, input_w]
        y3 = torch.cat((x, x1, x2, x3), 1)
        # [input_nb, input_nc, input_h, input_w]
        x4 = self.conv(y3)
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x + x4)
        out = self.relu(out)
        
        return out


class AM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128, reduction=16):
        super(AM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.skconv = SK_Conv(num_inputs=3, input_nc=input_nc, reduction=reduction)
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(x1)
        x2 = self.relu(x2)
        
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(x2)
        x3 = self.relu(x3)
        skout = self.skconv([x1, x2, x3])
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(skout)
        out = self.relu(out)
        
        return out


class RAM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128, reduction=16):
        super(RAM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.skconv = SK_Conv(num_inputs=3, input_nc=input_nc, reduction=reduction)
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(x1)
        x2 = self.relu(x2)
        
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(x2)
        x3 = self.relu(x3)
        skout = self.skconv([x1, x2, x3])
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x + skout)
        out = self.relu(out)
        
        return out


class DAM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128, reduction=16):
        super(DAM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(2 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(3 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.skconv = SK_Conv(num_inputs=3, input_nc=input_nc, reduction=reduction)
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, 2 * input_nc, input_h, input_w]
        y1 = torch.cat((x, x1), 1)
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(y1)
        x2 = self.relu(x2)
        
        # [input_nb, 3 * input_nc, input_h, input_w]
        y2 = torch.cat((x, x1, x2), 1)
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(y2)
        x3 = self.relu(x3)
        skout = self.skconv([x1, x2, x3])
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(skout)
        out = self.relu(out)
        
        return out


class RDAM(nn.Module):
    def __init__(self, input_nc=64, output_nc=128, reduction=16):
        super(RDAM, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(2 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(3 * input_nc, input_nc, 3, padding=1),
            nn.BatchNorm2d(input_nc)
        )
        self.skconv = SK_Conv(num_inputs=3, input_nc=input_nc, reduction=reduction)
        self.conv = nn.Sequential(
            nn.Conv2d(4 * input_nc, input_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(input_nc),
        )
        self.final_conv = nn.Sequential(
            nn.Conv2d(input_nc, output_nc, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(output_nc),
        )
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        # [input_nb, input_nc, input_h, input_w]
        x1 = self.conv1(x)
        x1 = self.relu(x1)
        
        # [input_nb, 2 * input_nc, input_h, input_w]
        y1 = torch.cat((x, x1), 1)
        # [input_nb, input_nc, input_h, input_w]
        x2 = self.conv2(y1)
        x2 = self.relu(x2)
        
        # [input_nb, 3 * input_nc, input_h, input_w]
        y2 = torch.cat((x, x1, x2), 1)
        # [input_nb, input_nc, input_h, input_w]
        x3 = self.conv3(y2)
        x3 = self.relu(x3)
        
        # [input_nb, 4 * input_nc, input_h, input_w]
        y3 = torch.cat((x, x1, x2, x3), 1)
        # [input_nb, input_nc, input_h, input_w]
        x4 = self.conv(y3)
        skout = self.skconv([x1, x2, x3])
        
        # [input_nb, output_nc, input_h, input_w]
        out = self.final_conv(x + x4 + skout)
        out = self.relu(out)
        
        return out

# -*- coding: utf-8 -*-

import torch
from torch import nn
import torch.nn.functional as F


class RDANet(nn.Module):
    def __init__(self, block, input_nc=3, num_classes=10):
        super(RDANet, self).__init__()
        assert num_classes > 1
        
        self.layer0 = nn.Sequential(
            nn.Conv2d(input_nc, 48, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False),
            nn.BatchNorm2d(48, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU(inplace=True))
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)
        
        self.layer1 = block(input_nc=48, output_nc=96)
        self.layer2 = block(input_nc=96, output_nc=192)
        #self.layer3 = block(input_nc=256, output_nc=512)
        #self.layer4 = block(input_nc=512, output_nc=1024)
        #self.fc = nn.Conv2d(1024, num_classes, kernel_size=1, stride=1, padding=0, bias=True)
        
    def forward(self, x):
        x = self.layer0(x)
        x = self.maxpool(x)
        
        x = self.layer1(x)
        x = self.maxpool(x)
        
        x = self.layer2(x)
        x = self.maxpool(x)
        
        #x = self.layer3(x)
        #x = self.maxpool(x)
        
        #x = self.layer4(x)
        #x = self.maxpool(x)
        
        gap = F.adaptive_avg_pool2d(x, 1).squeeze()
        #out = self.fc(gap).squeeze()
        
        return gap #F.softmax(out, dim=1)
